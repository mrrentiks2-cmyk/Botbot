Здесь должен лежать исходный код llama.cpp (b11836).
Сборка на GitHub скачивает его автоматически. Для сборки на компьютере выполните:
  git clone --depth 1 --branch b11836 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
